G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-07-13T02:58:03+08:00*
G04 #@! TF.ProjectId,keysdock,6b657973-646f-4636-9b2e-6b696361645f,0.3.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-07-13 02:58:03*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
